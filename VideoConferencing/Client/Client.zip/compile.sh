g++ -std=c++11 -o client -pthread -lasound AudioInterface.cpp AudioInterface.h MainClient.cpp AudioClient.cpp AudioClient.h
